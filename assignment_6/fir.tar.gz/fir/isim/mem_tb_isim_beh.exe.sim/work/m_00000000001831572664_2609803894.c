/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/pclab15/Downloads/assignment_6/memtransfer.v";
static int ng1[] = {8, 0};
static unsigned int ng2[] = {0U, 0U};
static int ng3[] = {0, 0};
static unsigned int ng4[] = {7U, 0U};
static unsigned int ng5[] = {1U, 0U};
static unsigned int ng6[] = {2U, 0U};
static unsigned int ng7[] = {5U, 0U};
static unsigned int ng8[] = {6U, 0U};
static unsigned int ng9[] = {3U, 0U};
static int ng10[] = {1, 0};
static unsigned int ng11[] = {4U, 0U};



static void Always_15_0(char *t0)
{
    char t4[8];
    char t7[8];
    char t10[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    char *t8;
    char *t9;
    char *t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    int t19;
    int t20;

LAB0:    t1 = (t0 + 1524U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(15, ng0);
    t2 = (t0 + 1704);
    *((int *)t2) = 1;
    t3 = (t0 + 1548);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(15, ng0);

LAB5:    xsi_set_current_line(16, ng0);
    t5 = (t0 + 600U);
    t6 = *((char **)t5);
    t5 = ((char*)((ng1)));
    t8 = (t0 + 600U);
    t9 = *((char **)t8);
    memset(t10, 0, 8);
    t8 = (t10 + 4);
    t11 = (t9 + 4);
    t12 = *((unsigned int *)t9);
    t13 = (t12 >> 7);
    t14 = (t13 & 1);
    *((unsigned int *)t10) = t14;
    t15 = *((unsigned int *)t11);
    t16 = (t15 >> 7);
    t17 = (t16 & 1);
    *((unsigned int *)t8) = t17;
    xsi_vlog_mul_concat(t7, 8, 1, t5, 1U, t10, 1);
    xsi_vlogtype_concat(t4, 16, 16, 2U, t7, 8, t6, 8);
    t18 = (t0 + 1012);
    xsi_vlogvar_assign_value(t18, t4, 0, 0, 16);
    xsi_set_current_line(17, ng0);
    t2 = (t0 + 692U);
    t3 = *((char **)t2);

LAB6:    t2 = ((char*)((ng2)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 3, t2, 3);
    if (t19 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng4)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 3, t2, 3);
    if (t19 == 1)
        goto LAB9;

LAB10:    t5 = ((char*)((ng5)));
    t20 = xsi_vlog_unsigned_case_compare(t3, 3, t5, 3);
    if (t20 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng6)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 3, t2, 3);
    if (t19 == 1)
        goto LAB13;

LAB14:    t5 = ((char*)((ng7)));
    t20 = xsi_vlog_unsigned_case_compare(t3, 3, t5, 3);
    if (t20 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng8)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 3, t2, 3);
    if (t19 == 1)
        goto LAB17;

LAB18:    t5 = ((char*)((ng9)));
    t20 = xsi_vlog_unsigned_case_compare(t3, 3, t5, 3);
    if (t20 == 1)
        goto LAB19;

LAB20:    t2 = ((char*)((ng11)));
    t19 = xsi_vlog_unsigned_case_compare(t3, 3, t2, 3);
    if (t19 == 1)
        goto LAB21;

LAB22:
LAB23:    goto LAB2;

LAB7:    xsi_set_current_line(18, ng0);
    t5 = ((char*)((ng3)));
    t6 = (t0 + 920);
    xsi_vlogvar_wait_assign_value(t6, t5, 0, 0, 16, 0LL);
    goto LAB23;

LAB9:    goto LAB7;

LAB11:    xsi_set_current_line(19, ng0);
    t6 = (t0 + 1012);
    t8 = (t6 + 36U);
    t9 = *((char **)t8);
    t11 = (t0 + 920);
    xsi_vlogvar_wait_assign_value(t11, t9, 0, 0, 16, 0LL);
    goto LAB23;

LAB13:    goto LAB11;

LAB15:    xsi_set_current_line(20, ng0);
    t6 = (t0 + 1012);
    t8 = (t6 + 36U);
    t9 = *((char **)t8);
    memset(t4, 0, 8);
    xsi_vlog_unsigned_unary_minus(t4, 16, t9, 16);
    t11 = (t0 + 920);
    xsi_vlogvar_wait_assign_value(t11, t4, 0, 0, 16, 0LL);
    goto LAB23;

LAB17:    goto LAB15;

LAB19:    xsi_set_current_line(21, ng0);
    t6 = (t0 + 1012);
    t8 = (t6 + 36U);
    t9 = *((char **)t8);
    t11 = ((char*)((ng10)));
    memset(t4, 0, 8);
    xsi_vlog_unsigned_lshift(t4, 16, t9, 16, t11, 32);
    t18 = (t0 + 920);
    xsi_vlogvar_wait_assign_value(t18, t4, 0, 0, 16, 0LL);
    goto LAB23;

LAB21:    xsi_set_current_line(22, ng0);
    t5 = (t0 + 1012);
    t6 = (t5 + 36U);
    t8 = *((char **)t6);
    memset(t4, 0, 8);
    xsi_vlog_unsigned_unary_minus(t4, 16, t8, 16);
    t9 = ((char*)((ng10)));
    memset(t7, 0, 8);
    xsi_vlog_unsigned_lshift(t7, 16, t4, 16, t9, 32);
    t11 = (t0 + 920);
    xsi_vlogvar_wait_assign_value(t11, t7, 0, 0, 16, 0LL);
    goto LAB23;

}


extern void work_m_00000000001831572664_2609803894_init()
{
	static char *pe[] = {(void *)Always_15_0};
	xsi_register_didat("work_m_00000000001831572664_2609803894", "isim/mem_tb_isim_beh.exe.sim/work/m_00000000001831572664_2609803894.didat");
	xsi_register_executes(pe);
}
