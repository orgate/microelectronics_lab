/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    xilinxcorelib_ver_m_00000000001358910285_2366102939_init();
    xilinxcorelib_ver_m_00000000001687936702_2690486219_init();
    xilinxcorelib_ver_m_00000000000277421008_0130978082_init();
    xilinxcorelib_ver_m_00000000001603977570_3258046356_init();
    work_m_00000000002489990758_2205736262_init();
    xilinxcorelib_ver_m_00000000000277421008_1546405106_init();
    xilinxcorelib_ver_m_00000000001603977570_3770148249_init();
    work_m_00000000000403262735_3281556929_init();
    work_m_00000000001831572664_2609803894_init();
    work_m_00000000000040301213_0196381976_init();
    work_m_00000000000601801888_1143523637_init();
    work_m_00000000000367079507_0127240469_init();
    work_m_00000000004164996728_3417465232_init();
    work_m_00000000000395970053_2780383046_init();
    work_m_00000000000893168720_0456519330_init();
    work_m_00000000000803055554_1973615985_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000000803055554_1973615985");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
