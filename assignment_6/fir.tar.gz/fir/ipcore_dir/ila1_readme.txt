The following files were generated for 'ila1' in directory
/home/pclab15/fir/ipcore_dir/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * ila1.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * ila1.cdc
   * ila1.constraints/ila1.ucf
   * ila1.constraints/ila1.xdc
   * ila1.ncf
   * ila1.ngc
   * ila1.ucf
   * ila1.v
   * ila1.veo
   * ila1.xdc
   * ila1_xmdf.tcl

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * ila1.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * ila1.sym

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * ila1.gise
   * ila1.xise

Deliver Readme:
   Readme file for the IP.

   * ila1_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * ila1_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

