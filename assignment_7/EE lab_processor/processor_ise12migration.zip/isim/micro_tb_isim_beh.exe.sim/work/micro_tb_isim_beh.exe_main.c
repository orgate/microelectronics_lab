/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000001233828288_2725559894_init();
    work_m_00000000001475711342_2828040072_init();
    work_m_00000000001657598426_3866583278_init();
    work_m_00000000004154223164_3381898454_init();
    xilinxcorelib_ver_m_00000000001184809869_3724833731_init();
    xilinxcorelib_ver_m_00000000001036818086_1440133065_init();
    xilinxcorelib_ver_m_00000000000414557669_3246871352_init();
    xilinxcorelib_ver_m_00000000002516893505_3155090117_init();
    work_m_00000000003645434707_1352674679_init();
    work_m_00000000002163067550_1351276808_init();
    work_m_00000000000094328515_1710855873_init();
    work_m_00000000003046569309_1729977324_init();
    work_m_00000000002013452923_2073120511_init();


    xsi_register_tops("work_m_00000000003046569309_1729977324");
    xsi_register_tops("work_m_00000000002013452923_2073120511");


    return xsi_run_simulation(argc, argv);

}
